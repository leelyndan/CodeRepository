// https://www.npmjs.com/package/es2015-i18n-tag

module.exports = {
  fr: require('./fr.json'),
  ja: require('./ja.json')
}
